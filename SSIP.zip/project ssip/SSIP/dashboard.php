<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['user']['role'];

if ($role === 'admin') {
    header("Location: admin_dashboard.php");
    exit;
} elseif ($role === 'user') {
    header("Location: user_dashboard.php");
    exit;
} else {
    echo "Role tidak dikenali.";
    exit;
}
