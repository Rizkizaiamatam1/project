<?php
session_start();
include 'config.php';

// Hanya admin yang boleh akses
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Pastikan ada ID yang diterima dari URL
if (isset($_GET['id'])) {
    $book_id = $_GET['id'];

    // Ambil data buku berdasarkan ID
    $query = "SELECT * FROM books WHERE id = $book_id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $book = mysqli_fetch_assoc($result);
    } else {
        echo "Book not found.";
        exit;
    }
}

// Proses update data buku jika form di-submit
if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $category = $_POST['category'];
    $status = $_POST['status'];

    // Update data buku
    $update_query = "UPDATE books SET title = '$title', author = '$author', category = '$category', status = '$status' WHERE id = $book_id";

    if (mysqli_query($conn, $update_query)) {
        header("Location: books.php?message=Book updated successfully");
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Book</title>
  <link rel="stylesheet" href="dashboard.css"> <!-- Custom CSS (sidebar, layout) -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
  <div class="mycontainer">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2>PUSTAKA</h2>
      <div class="profile">
        <img src="user.png" alt="User">
        <p><strong><?= $_SESSION['user']['name'] ?></strong><br><span>Admin</span></p>
      </div>
      <ul>
        <li><a href="admin_dashboard.php">Dashboard</a></li>
        <li class="active"><a href="books.php">Books</a></li>
        <li><a href="loans.php">Loans</a></li>
        <li><a href="status_books.php">Status Books</a></li>
        <li><a href="logout.php" style="color:red;">Logout</a></li>
      </ul>
    </div>

    <!-- Main content -->
    <div class="main p-4">
      <h1 class="mb-4">Edit Book</h1>
      <form method="POST">
        <div class="mb-3">
          <label for="title" class="form-label">Title</label>
          <input type="text" class="form-control" id="title" name="title" value="<?= $book['title'] ?>" required>
        </div>
        <div class="mb-3">
          <label for="author" class="form-label">Author</label>
          <input type="text" class="form-control" id="author" name="author" value="<?= $book['author'] ?>" required>
        </div>
        <div class="mb-3">
          <label for="category" class="form-label">Category</label>
          <input type="text" class="form-control" id="category" name="category" value="<?= $book['category'] ?>" required>
        </div>
        <div class="mb-3">
          <label for="status" class="form-label">Status</label>
          <select class="form-control" id="status" name="status" required>
            <option value="available" <?= ($book['status'] == 'available') ? 'selected' : ''; ?>>Available</option>
            <option value="borrowed" <?= ($book['status'] == 'borrowed') ? 'selected' : ''; ?>>Borrowed</option>
            <option value="reserved" <?= ($book['status'] == 'reserved') ? 'selected' : ''; ?>>Reserved</option>
          </select>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Update Book</button>
      </form>
    </div>
  </div>

</body>
</html>
