<?php
session_start();
include 'config.php';

// Cek user login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil buku yang masih dipinjam
$query = "SELECT borrowed_books.*, books.title 
          FROM borrowed_books
          JOIN books ON borrowed_books.book_id = books.id
          WHERE borrowed_books.user_id = $user_id AND borrowed_books.status = 'Pending'";
$result = $conn->query($query);

if (isset($_POST['return'])) {
    $borrow_id = $_POST['borrow_id'];
    $return_date = date('Y-m-d');

    // Update borrowed_books status
    $conn->query("UPDATE borrowed_books SET status = 'Returned' WHERE id = $borrow_id");

    // Masukkan ke returns
    $conn->query("INSERT INTO returns (borrow_id, return_date, `condition`) VALUES ($borrow_id, '$return_date', 'Good')");

    // Update book status kembali Available
    $borrow = $conn->query("SELECT book_id FROM borrowed_books WHERE id = $borrow_id")->fetch_assoc();
    $book_id = $borrow['book_id'];
    $conn->query("UPDATE books SET status = 'Available' WHERE id = $book_id");

    // Cek denda (kalau terlambat)
    $due_date = $conn->query("SELECT due_date FROM borrowed_books WHERE id = $borrow_id")->fetch_assoc()['due_date'];
    if ($return_date > $due_date) {
        $days_late = (strtotime($return_date) - strtotime($due_date)) / (60 * 60 * 24);
        $fine_amount = $days_late * 1000; // Rp1000 per hari

        $conn->query("INSERT INTO fines (user_id, amount, description) VALUES ($user_id, $fine_amount, 'Late return')");
    }

    header('Location: loans.php');
}
?>

<h1>Return a Book</h1>
<a href="dashboard.php">Back to Dashboard</a>

<form method="post">
    <select name="borrow_id" required>
        <option value="">-- Select Borrowed Book --</option>
        <?php while ($row = $result->fetch_assoc()): ?>
            <option value="<?= $row['id'] ?>"><?= $row['title'] ?> (Borrowed: <?= $row['borrow_date'] ?>)</option>
        <?php endwhile; ?>
    </select>
    <button name="return">Return Book</button>
</form>
