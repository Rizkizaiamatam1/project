<?php
session_start();

// Include the database connection
include 'config.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit;
}

// Initialize variables
$title = $author = $genre = '';
$status = 'available';  // Default to 'available'
$errors = [];
$success = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $genre = trim($_POST['genre']);
    $status = trim($_POST['status']);  // Get status from the form
    
    // Validate inputs
    if (empty($title)) {
        $errors['title'] = 'Title is required';
    }
    if (empty($author)) {
        $errors['author'] = 'Author is required';
    }
    if (empty($genre)) {
        $errors['genre'] = 'Genre is required';
    }
    if (empty($status)) {
        $errors['status'] = 'Status is required';
    }

    // If no errors, insert into database
    if (empty($errors)) {
        $title = mysqli_real_escape_string($conn, $title);
        $author = mysqli_real_escape_string($conn, $author);
        $genre = mysqli_real_escape_string($conn, $genre);
        $status = mysqli_real_escape_string($conn, $status);
        
        $query = "INSERT INTO books (title, author, genre, status) 
                  VALUES ('$title', '$author', '$genre', '$status')";
        
        if (mysqli_query($conn, $query)) {
            $success = 'Book added successfully!';
            // Clear form
            $title = $author = $genre = '';
            $status = 'available';  // Reset to default
        } else {
            $errors['database'] = 'Error adding book: ' . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add New Book | PUSTAKA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Sidebar Styles - Consistent with other pages */
    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }
    
    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }
    
    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }
    
    .profile p {
      margin: 0;
    }
    
    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }
    
    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }
    
    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }
    
    .sidebar ul li {
      margin: 8px 0;
    }
    
    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    
    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }
    
    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }
    
    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }
    
    /* Main Content */
    .main {
      margin-left: 270px;
      padding: 20px;
    }
    
    /* Form Styles */
    .form-container {
      max-width: 800px;
      margin: 0 auto;
      background-color: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .form-title {
      color: #6a11cb;
      margin-bottom: 30px;
      text-align: center;
    }
    
    .form-label {
      font-weight: 600;
      color: #495057;
    }
    
    .form-control, .form-select {
      border-radius: 8px;
      padding: 12px 15px;
      border: 1px solid #e0e0e0;
    }
    
    .form-control:focus, .form-select:focus {
      border-color: #6a11cb;
      box-shadow: 0 0 0 0.25rem rgba(106, 17, 203, 0.25);
    }
    
    .btn-submit {
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
      border: none;
      border-radius: 8px;
      padding: 12px 30px;
      font-weight: 600;
      color: white;
      transition: all 0.3s;
    }
    
    .btn-submit:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .is-invalid {
      border-color: #dc3545;
    }
    
    .invalid-feedback {
      color: #dc3545;
      font-size: 0.875rem;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }
      
      .main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>   
      </div>
  <div class="mycontainer">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2>PUSTAKA</h2>
      <div class="profile">
            <p><strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong><br><span>Admin</span></p>
      </div>
      <ul>
        <li>
          <a href="user_dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'user_dashboard.php' ? '' : '' ?>">
            <i class="fas fa-home"></i> Dashboard
          </a>
        </li>
        <li>
          <a href="books.php" class="<?= basename($_SERVER['PHP_SELF']) == 'books.php' ? '' : '' ?>">
            <i class="fas fa-book"></i> Books
          </a>
        </li>
        <li>
          <a href="borrow.php" class="<?= basename($_SERVER['PHP_SELF']) == 'borrow.php' ? 'active' : '' ?>">
            <i class="fas fa-bookmark"></i> Borrow
          </a>
        </li>
        <li>
          <a href="aboutus.php" class="<?= basename($_SERVER['PHP_SELF']) == 'aboutus.php' ? '' : '' ?>">
            <i class="fas fa-info-circle"></i> About Us
          </a>
        </li>
        <li>
          <a href="logout.php" style="color:red;">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
    </div>

    <!-- Main Content -->
    <div class="main p-4">
      <div class="form-container">
        <h2 class="form-title"><i class="fas fa-plus-circle"></i> Add New Book</h2>
        
        <?php if (!empty($success)): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>
        
        <?php if (!empty($errors['database'])): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $errors['database'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>
        
        <form method="POST" action="add_book.php">
          <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control <?= isset($errors['title']) ? 'is-invalid' : '' ?>" 
                   id="title" name="title" value="<?= htmlspecialchars($title) ?>">
            <?php if (isset($errors['title'])): ?>
              <div class="invalid-feedback"><?= $errors['title'] ?></div>
            <?php endif; ?>
          </div>
          
          <div class="mb-3">
            <label for="author" class="form-label">Author</label>
            <input type="text" class="form-control <?= isset($errors['author']) ? 'is-invalid' : '' ?>" 
                   id="author" name="author" value="<?= htmlspecialchars($author) ?>">
            <?php if (isset($errors['author'])): ?>
              <div class="invalid-feedback"><?= $errors['author'] ?></div>
            <?php endif; ?>
          </div>
          
          <div class="mb-3">
            <label for="genre" class="form-label">Genre</label>
            <select class="form-select <?= isset($errors['genre']) ? 'is-invalid' : '' ?>" 
                    id="genre" name="genre">
              <option value="">Select Genre</option>
              <option value="Fiction" <?= $genre === 'Fiction' ? 'selected' : '' ?>>Fiction</option>
              <option value="Non-Fiction" <?= $genre === 'Non-Fiction' ? 'selected' : '' ?>>Non-Fiction</option>
              <option value="Science" <?= $genre === 'Science' ? 'selected' : '' ?>>Science</option>
              <option value="History" <?= $genre === 'History' ? 'selected' : '' ?>>History</option>
              <option value="Biography" <?= $genre === 'Biography' ? 'selected' : '' ?>>Biography</option>
              <option value="Fantasy" <?= $genre === 'Fantasy' ? 'selected' : '' ?>>Fantasy</option>
              <option value="Horror" <?= $genre === 'Horror' ? 'selected' : '' ?>>Horror</option>
              <option value="Romance" <?= $genre === 'Romance' ? 'selected' : '' ?>>Romance</option>
              <option value="Other" <?= $genre === 'Other' ? 'selected' : '' ?>>Other</option>
            </select>
            <?php if (isset($errors['genre'])): ?>
              <div class="invalid-feedback"><?= $errors['genre'] ?></div>
            <?php endif; ?>
          </div>
          
          <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-select <?= isset($errors['status']) ? 'is-invalid' : '' ?>" 
                    id="status" name="status">
              <option value="available" <?= $status === 'available' ? 'selected' : '' ?>>Available</option>
              <option value="out of stock" <?= $status === 'out of stock' ? 'selected' : '' ?>>Out of stock</option>
            </select>
            <?php if (isset($errors['status'])): ?>
              <div class="invalid-feedback"><?= $errors['status'] ?></div>
            <?php endif; ?>
          </div>
          
          <div class="d-grid">
            <button type="submit" class="btn btn-submit">
              <i class="fas fa-save"></i> Add Book
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
