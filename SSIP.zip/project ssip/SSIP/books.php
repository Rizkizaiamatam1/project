<?php
session_start();
include 'config.php';

// Cek jika pengguna sudah login
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}

// Fetch buku yang tersedia untuk dipinjam
$query = "SELECT * FROM books";
$result = mysqli_query($conn, $query);
if (!$result) {
  die("Query error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Your Books</title>
  <link rel="stylesheet" href="books.css"> <!-- Custom CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Sidebar Styles */
    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }

    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }

    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }

    .profile p {
      margin: 0;
    }

    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }

    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }

    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .sidebar ul li {
      margin: 8px 0;
    }

    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }

    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }

    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }

    .sidebar ul li a[style*="color:red"]:hover {
      background-color: #ffe6e6 !important;
    }

    /* Main Content */
    .main {
      margin-left: 270px;
      padding: 20px;
    }

    /* Table Styles */
    .table {
      background-color: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    }

    .table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }

      .main {
        margin-left: 0;
      }
    }
  </style>
</head>

<body>

  <!-- Sidebar Aesthetic -->
  <div class="sidebar">
    <h2>PUSTAKA</h2>
    <div class="profile">
      <p><strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong><br><span><?= ($_SESSION['user']['role'] == 'admin') ? 'Admin' : 'User' ?></span></p>
    </div>
    <ul>
      <li class="<?= basename($_SERVER['PHP_SELF']) == 'admin_dashboard.php' ? 'active' : '' ?>">
        <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
      </li>
      <li class="<?= basename($_SERVER['PHP_SELF']) == 'books.php' ? 'active' : '' ?>">
        <a href="books.php"><i class="fas fa-book"></i> Books</a>
      </li>
      <li class="<?= basename($_SERVER['PHP_SELF']) == 'borrow.php' ? 'active' : '' ?>">
        <a href="borrow.php"><i class="fas fa-bookmark"></i> Borrow</a>
      </li>
      <li class="<?= basename($_SERVER['PHP_SELF']) == 'aboutus.php' ? 'active' : '' ?>">
        <a href="aboutus.php"><i class="fas fa-info-circle"></i> About Us</a>
      </li>
      <li>
        <a href="logout.php" style="color:red;"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="main p-4">
    <h1 class="mb-4">Books Data</h1>

    <!-- Display "Add Book" button for Admin only -->
    <?php if ($_SESSION['user']['role'] == 'admin'): ?>
      <a href="add_book.php" class="btn btn-success mb-4">Add Book</a>
    <?php endif; ?>

    <table class="table table-striped">
      <thead>
        <tr>
          <th>No</th>
          <th>Title</th>
          <th>Author</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
          $status_color = ($row['quantity'] > 0) ? 'green' : 'red'; // Green for available, red for out of stock
          $status_text = ($row['quantity'] > 0) ? 'Available' : 'Out of stock';
          echo "<tr>
                <td>$no</td>
                <td>{$row['title']}</td>
                <td>{$row['author']}</td>
                <td style='color:$status_color;'>$status_text</td>
                <td>";

          // Hanya tampilkan tombol borrow jika buku tersedia
          if ($row['quantity'] > 0) {
            echo "<button class='btn btn-primary btn-sm borrowBtn' data-book-id='{$row['id']}'>Borrow</button>";
          } else {
            echo "<button class='btn btn-secondary btn-sm' disabled>Out of Stock</button>";
          }
          echo "</td></tr>";
          $no++;
        }
        ?>
      </tbody>
    </table>
  </div>

  <!-- Reminder Modal -->
  <div class="modal fade" id="reminderModal" tabindex="-1" aria-labelledby="reminderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <div class="modal-header bg-warning-subtle">
          <h5 class="modal-title" id="reminderModalLabel">📌 Book Borrowing Reminder</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ol>
            <li><strong>Books must be returned in good condition</strong> (no scribbles, folds, or physical damage).</li>
            <li><strong>Return the book by the specified due date.</strong> Late returns will result in a <span class="text-danger">7-day account suspension.</span></li>
            <li><strong>Lost books</strong> will incur a fine equal to the book's original price.</li>
            <li>Please double-check the book carefully before returning it. Library staff will inspect the book's condition.</li>
            <li><strong>Do not borrow more than the available stock.</strong></li>
          </ol>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" id="borrowConfirmBtn">I Understand</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Continue Borrow Modal -->
  <div class="modal fade" id="continueBorrowModal" tabindex="-1" aria-labelledby="continueBorrowModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <div class="modal-header bg-info">
          <h5 class="modal-title" id="continueBorrowModalLabel">Confirm Your Borrowing</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p><strong>Do you want to continue borrowing this book?</strong></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-success" id="continueBorrowBtn">Continue Borrow</button>
        </div>
      </div>
    </div>
  </div>

  <!-- JavaScript libraries -->
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    // Modal pop-up when Borrow button is clicked
    $(document).ready(function() {
      $('.borrowBtn').click(function() {
        var bookId = $(this).data('book-id');

        // Open the reminder modal
        var reminderModal = new bootstrap.Modal(document.getElementById('reminderModal'));
        reminderModal.show();

        // Once the user confirms in the first modal
        $('#borrowConfirmBtn').click(function() {
          // Open the second modal (Continue Borrow or Cancel)
          var continueBorrowModal = new bootstrap.Modal(document.getElementById('continueBorrowModal'));
          continueBorrowModal.show();

          // Once the user clicks Continue Borrow
          $('#continueBorrowBtn').click(function() {
            // Redirect to borrow.php with the selected book_id
            window.location.href = 'borrow.php?book_id=' + bookId;
          });
        });
      });
    });
  </script>
</body>

</html>