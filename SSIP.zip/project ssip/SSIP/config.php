<?php
// Database configuration
$host = 'localhost';
$username = 'root'; // Change if necessary
$password = ''; // Change if necessary
$dbname = 'perpus_db';

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
