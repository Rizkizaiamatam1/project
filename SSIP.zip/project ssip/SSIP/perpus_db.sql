-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Bulan Mei 2025 pada 10.17
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpus_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bans`
--

CREATE TABLE `bans` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `banned_at` date NOT NULL,
  `banned_until` date NOT NULL,
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(100) NOT NULL,
  `genre` varchar(100) DEFAULT NULL,
  `status` enum('available','borrowed','reserved') DEFAULT 'available',
  `quantity` int(11) DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `genre`, `status`, `quantity`) VALUES
(11, 'Harry Potter and the Sorcerer’s Stone', 'J.K. Rowling', 'Fiction', 'available', 0),
(12, 'Hujan', 'TereLiye', 'Fiction', 'available', 5),
(16, 'Laskar Pelangi', 'Andrea Hirata', 'Fiction', 'available', 4),
(17, 'The Little Prince', 'Antoine de Saint-Exupéry', 'Fiction', 'available', 5),
(19, 'Filosofi Teras', 'Henry Manampiring', 'Non-Fiction', 'available', 5),
(20, 'Atomic Habits', 'James Clear', 'Non-Fiction', 'available', 5),
(21, 'Sapiens: A Brief History of Humankind', 'Yuval Noah Harari', 'Non-Fiction', 'available', 5),
(24, 'Why? Weather', 'YeaRimDang', 'Science (Anak)', 'available', 5),
(25, 'Why? The Sea', 'YeaRimDang', 'Science (Anak)', 'available', 5),
(26, 'Little Kids First Big Book of Space', 'Catherine D. Hughes', 'Science (Anak)', 'available', 5),
(27, 'Danur', 'Risa Saraswati', 'Horror', 'available', 5),
(28, 'It', 'Stephen King', 'Horror', 'available', 5),
(29, 'The Haunting of Hill House', 'Shirley Jackson', 'Horror', 'available', 5),
(30, 'It Ends With Us', 'Colleen Hoover', 'Romance', 'available', 5),
(31, 'Love and Other Words', 'Christina Lauren', 'Romance', 'available', 5),
(32, 'Pride and Prejudice', 'Jane Austen', 'Romance', 'available', 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `borrow`
--

CREATE TABLE `borrow` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `borrow`
--

INSERT INTO `borrow` (`id`, `user_id`, `borrow_date`, `due_date`, `return_date`, `book_id`) VALUES
(42, 10, '2025-05-04', '0000-00-00', '2025-05-18', 11),
(43, 11, '2025-05-05', '0000-00-00', '2025-05-19', 16);

-- --------------------------------------------------------

--
-- Struktur dari tabel `borrowed_books`
--

CREATE TABLE `borrowed_books` (
  `id` int(11) NOT NULL,
  `borrow_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `borrowed_books_view`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `borrowed_books_view` (
`username` varchar(100)
,`book_title` varchar(255)
,`borrow_date` date
,`return_date` date
,`borrow_duration` int(7)
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(7, 'rizki', 'zaimatam@gmail.com', '$2y$10$sFRN2DcbeA/ri2mydD4eiumRcRJvi33kaYvOKPzCxZ2IiJMBGifjG', 'admin', '2025-05-04 10:58:21'),
(10, 'putri', 'padang@gmail.com', '$2y$10$qojcg/CenxmyffZxASOGeOiCjnr6r5WGIxYE7g3W3gkaDmkgTsnOe', 'user', '2025-05-04 22:14:01'),
(11, 'sopiah', 'iah@gmai.com', '$2y$10$he6AQ4vkv437XYh40T06ReHX1vET.QFxBoeOaNdA0.MZSzFUaBeie', 'user', '2025-05-04 22:14:40'),
(12, 'koko', 'koko@gmail.com', '$2y$10$IsKK6mcJbEm6sCYIj6eveucORc48zwpSH5nzLW1IBATHoHV5PB0Mq', 'user', '2025-05-04 22:14:55'),
(13, 'Nabila', 'Latasya@gmail.com', '$2y$10$pPNpbsVimQBFkwQyUvxOfO27K5MvJINVHtpmtUQiPZE7apdkeTalK', 'admin', '2025-05-04 22:17:11'),
(15, 'melisa', 'melisa@gmail.com', '$2y$10$pooZMReTdtCLxWjdPHg8Z..gaPmQTUmFlJSOe5qWZ2I4ZagAjVuFK', 'admin', '2025-05-05 11:01:33');

-- --------------------------------------------------------

--
-- Struktur untuk view `borrowed_books_view`
--
DROP TABLE IF EXISTS `borrowed_books_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `borrowed_books_view`  AS SELECT `u`.`name` AS `username`, `b`.`title` AS `book_title`, `br`.`borrow_date` AS `borrow_date`, `br`.`return_date` AS `return_date`, to_days(`br`.`return_date`) - to_days(`br`.`borrow_date`) AS `borrow_duration` FROM ((`borrow` `br` join `users` `u` on(`br`.`user_id` = `u`.`id`)) join `books` `b` on(`br`.`book_id` = `b`.`id`)) WHERE `br`.`return_date` is not null ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bans`
--
ALTER TABLE `bans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_book_id` (`book_id`);

--
-- Indeks untuk tabel `borrowed_books`
--
ALTER TABLE `borrowed_books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `borrow_id` (`borrow_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indeks untuk tabel `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bans`
--
ALTER TABLE `bans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT untuk tabel `borrow`
--
ALTER TABLE `borrow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT untuk tabel `borrowed_books`
--
ALTER TABLE `borrowed_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `bans`
--
ALTER TABLE `bans`
  ADD CONSTRAINT `bans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `borrow`
--
ALTER TABLE `borrow`
  ADD CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_book_id` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Ketidakleluasaan untuk tabel `borrowed_books`
--
ALTER TABLE `borrowed_books`
  ADD CONSTRAINT `borrowed_books_ibfk_1` FOREIGN KEY (`borrow_id`) REFERENCES `borrow` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `borrowed_books_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
