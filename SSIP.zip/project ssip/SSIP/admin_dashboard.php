<?php  
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Ambil nama admin dari session
$admin_name = $_SESSION['user']['name'];

// Hitung total buku
$book_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM books");
$total_books = mysqli_fetch_assoc($book_result)['total'] ?? 0;

// Hitung total user
$user_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='user'");
$total_users = mysqli_fetch_assoc($user_result)['total'] ?? 0;

// Hitung total peminjaman aktif
$borrow_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM borrow WHERE return_date >= CURDATE()");
$active_borrows = mysqli_fetch_assoc($borrow_result)['total'] ?? 0;

// Hitung total buku yang terlambat dikembalikan
$overdue_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM borrow WHERE return_date < CURDATE()");
$overdue_books = mysqli_fetch_assoc($overdue_result)['total'] ?? 0;

// Ambil data peminjaman terakhir
$recent_borrows_result = mysqli_query($conn, "
    SELECT b.title, u.name AS user_name, br.borrow_date, br.return_date 
    FROM borrow br 
    JOIN books b ON br.book_id = b.id 
    JOIN users u ON br.user_id = u.id 
    ORDER BY br.borrow_date DESC 
    LIMIT 5
");

// Ambil data user terbaru
$recent_users_result = mysqli_query($conn, "
    SELECT name, email, created_at 
    FROM users 
    WHERE role='user' 
    ORDER BY created_at DESC 
    LIMIT 5
");

// Process book borrowing
if (isset($_GET['book_id'])) {
    $book_id = $_GET['book_id'];
    $user_id = $_SESSION['user']['id'];
    
    // Get book quantity
    $book_query = "SELECT quantity FROM books WHERE id = '$book_id'";
    $book_result = mysqli_query($conn, $book_query);
    
    if (!$book_result) {
        die("Query error: " . mysqli_error($conn));
    }
    
    $book_data = mysqli_fetch_assoc($book_result);

    if ($book_data && $book_data['quantity'] > 0) {
        // Calculate dates (borrow date + 14 days)
        $borrow_date = date('Y-m-d');
        $return_date = date('Y-m-d', strtotime('+14 days'));

        // Insert borrow record
        $borrow_query = "INSERT INTO borrow (user_id, book_id, borrow_date, return_date) 
                         VALUES ('$user_id', '$book_id', '$borrow_date', '$return_date')";
                             
        if (mysqli_query($conn, $borrow_query)) {
            // Update book quantity
            $update_quantity_query = "UPDATE books SET quantity = quantity - 1 WHERE id = '$book_id'";
            mysqli_query($conn, $update_quantity_query);

            $_SESSION['reminder'] = true;
            
            // Redirect to avoid resubmission
            header("Location: borrow.php");
            exit;
        } else {
            $_SESSION['error_message'] = 'Failed to borrow the book: ' . mysqli_error($conn);
        }
    } else {
        $_SESSION['error_message'] = 'Sorry, this book is out of stock.';
    }
}

// Fetch user's borrowed books
$user_id = $_SESSION['user']['id'];
$query = "SELECT b.title, b.author, br.borrow_date, br.return_date, br.id AS borrow_id 
          FROM borrow br 
          JOIN books b ON br.book_id = b.id 
          WHERE br.user_id = '$user_id'";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query error: " . mysqli_error($conn));
}

// Delete borrow history
if (isset($_GET['delete'])) {
    $borrow_id = $_GET['delete'];
    $delete_query = "DELETE FROM borrow WHERE id = $borrow_id AND return_date < CURDATE()";
    $delete_result = mysqli_query($conn, $delete_query);
    if ($delete_result) {
        $_SESSION['success_message'] = "Borrow record deleted successfully.";
        header("Location: borrow.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to delete borrow record.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard | PUSTAKA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Sidebar Styles - Consistent with other pages */
    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }
    
    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }
    
    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }
    
    .profile p {
      margin: 0;
    }
    
    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }
    
    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }
    
    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }
    
    .sidebar ul li {
      margin: 8px 0;
    }
    
    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    
    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }
    
    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }
    
    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }
    
    .sidebar ul li a[style*="color:red"]:hover {
      background-color: #ffe6e6 !important;
    }
    
    /* Main Content */
    .main {
      margin-left: 270px;
      padding: 20px;
    }
    
    /* Dashboard Cards */
    .dashboard-card {
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
      transition: transform 0.3s ease;
    }
    
    .dashboard-card:hover {
      transform: translateY(-5px);
    }
    
    .card-books {
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
      color: white;
    }
    
    .card-borrowed {
      background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
      color: white;
    }
    
    .card-recent {
      background: linear-gradient(135deg, #f46b45 0%, #eea849 100%);
      color: white;
    }
    
    .card-icon {
      font-size: 2.5rem;
      margin-bottom: 15px;
    }
    
    /* Recent Books Table */
    .recent-table {
      background-color: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .recent-table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }
      
      .main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>
  <div class="mycontainer">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2>PUSTAKA</h2>
      <div class="profile">
      <p><strong>Welcome, <?= $admin_name ?>!</strong><br><span>Administrator</span></p></div>
      <ul>
        <li>
          <a href="admin_dashboard.php" class="active">
            <i class="fas fa-home"></i> Dashboard
          </a>
        </li>
        <li>
          <a href="books.php">
            <i class="fas fa-book"></i> Books
          </a>
        </li>
        <li>
          <a href="borrow.php">
            <i class="fas fa-bookmark"></i> Borrow
          </a>
        </li>
        <li>
          <a href="aboutus.php">
            <i class="fas fa-info-circle"></i> About Us
          </a>
        </li>
        <li>
          <a href="logout.php" style="color:red;">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
    </div>

    <!-- Main Content -->
    <div class="main p-4">
      <h1 class="mb-4">Admin Dashboard</h1>
      
      <!-- Stats Cards -->
      <div class="row">
        <div class="col-md-3">
          <div class="dashboard-card card-books">
            <div class="card-icon">
              <i class="fas fa-book-open"></i>
            </div>
            <h3><?= $total_books ?></h3>
            <p>Total Books</p>
          </div>
        </div>
        
        <div class="col-md-3">
          <div class="dashboard-card card-users">
            <div class="card-icon">
              <i class="fas fa-users"></i>
            </div>
            <h3><?= $total_users ?></h3>
            <p>Registered Users</p>
          </div>
        </div>
        
        <div class="col-md-3">
          <div class="dashboard-card card-borrows">
            <div class="card-icon">
              <i class="fas fa-bookmark"></i>
            </div>
            <h3><?= $active_borrows ?></h3>
            <p>Active Borrows</p>
          </div>
        </div>
        
        <div class="col-md-3">
          <div class="dashboard-card card-overdue">
            <div class="card-icon">
              <i class="fas fa-exclamation-circle"></i>
            </div>
            <h3><?= $overdue_books ?></h3>
            <p>Overdue Books</p>
          </div>
        </div>
      </div>
      
      <!-- Recent Activity Section -->
      <div class="row mt-5">
        <!-- Recent Borrows -->
        <div class="col-md-8">
          <h3 class="section-title">Recent Borrows</h3>
          <?php if(mysqli_num_rows($recent_borrows_result) > 0): ?>
            <div class="table-responsive data-table">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Book Title</th>
                    <th>User</th>
                    <th>Borrow Date</th>
                    <th>Return Date</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while($borrow = mysqli_fetch_assoc($recent_borrows_result)): ?>
                    <tr>
                      <td><?= htmlspecialchars($borrow['title']) ?></td>
                      <td><?= htmlspecialchars($borrow['user_name']) ?></td>
                      <td><?= $borrow['borrow_date'] ?></td>
                      <td><?= $borrow['return_date'] ?></td>
                      <td>
                        <?php 
                          $return_date = new DateTime($borrow['return_date']);
                          $today = new DateTime();
                          if ($return_date < $today) {
                            echo '<span class="badge bg-danger">Overdue</span>';
                          } else {
                            echo '<span class="badge bg-success">Active</span>';
                          }
                        ?>
                      </td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <div class="alert alert-info">
              No recent borrows found.
            </div>
          <?php endif; ?>
        </div>
        
        <!-- Recent Users -->
        <div class="col-md-4">
          <h3 class="section-title">Recent Users</h3>
          <?php if(mysqli_num_rows($recent_users_result) > 0): ?>
            <div class="table-responsive data-table">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Joined</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while($user = mysqli_fetch_assoc($recent_users_result)): ?>
                    <tr>
                      <td><?= htmlspecialchars($user['name']) ?></td>
                      <td><?= htmlspecialchars($user['email']) ?></td>
                      <td><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <div class="alert alert-info">
              No recent users found.
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>