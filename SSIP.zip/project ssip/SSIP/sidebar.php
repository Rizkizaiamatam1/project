<div class="sidebar">
  <h2 class="sidebar-logo">PUSTAKA</h2>
  <div class="profile">
    <p>
      <strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong>
      <br>
      <span>User</span>
    </p>
  </div>
    <li class="<?= basename($_SERVER['PHP_SELF']) == basename($dashboard_link) ? 'active' : '' ?>">
      <a href="<?= $dashboard_link ?>"><i class="fas fa-home"></i> Dashboard</a>
    </li>
    <li class="<?= basename($_SERVER['PHP_SELF']) == 'books.php' ? 'active' : '' ?>">
      <a href="books.php"><i class="fas fa-book"></i> Books</a>
    </li>
    <li class="<?= basename($_SERVER['PHP_SELF']) == 'borrow.php' ? 'active' : '' ?>">
      <a href="borrow.php"><i class="fas fa-bookmark"></i> Borrow</a>
    </li>
    <li class="<?= basename($_SERVER['PHP_SELF']) == 'aboutus.php' ? 'active' : '' ?>">
      <a href="aboutus.php"><i class="fas fa-info-circle"></i> About Us</a>
    </li>
    <li class="logout-item">
      <a href="logout.php" style="color:red;"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </li>
  </ul>
</div>