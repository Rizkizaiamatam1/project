<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Fetch borrowed books
$user_id = $_SESSION['user']['id'];
$query = "SELECT b.title, b.author, br.borrow_date, br.return_date 
          FROM borrow br 
          JOIN books b ON br.book_id = b.id 
          WHERE br.user_id = '$user_id'";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Borrowed Books</title>
  <link rel="stylesheet" href="books.css"> <!-- Custom CSS (sidebar, layout) -->
</head>
<body>
  <div class="mycontainer">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2>PUSTAKA</h2>
      <div class="profile">
        <p><strong>Halo, <?= $_SESSION['user']['name'] ?>!</strong><br><span>User</span></p>
      </div>
      <ul>
        <li><a href="user_dashboard.php">Dashboard</a></li>
        <li class="active"><a href="borrowed_books.php">Borrowed Books</a></li>
        <li><a href="books.php">Books</a></li>
        <li><a href="borrow.php">Borrow</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="logout.php" style="color:red;">Logout</a></li>
      </ul>
    </div>

    <!-- Main content -->
    <div class="main p-4">
      <h1 class="mb-4">Borrowed Books</h1>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Title</th>
            <th>Author</th>
            <th>Borrow Date</th>
            <th>Return Date</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 1;
          while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
              <td>$no</td>
              <td>{$row['title']}</td>
              <td>{$row['author']}</td>
              <td>{$row['borrow_date']}</td>
              <td>{$row['return_date']}</td>
            </tr>";
            $no++;
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
