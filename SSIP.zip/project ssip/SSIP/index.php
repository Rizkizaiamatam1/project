<?php
// Optional: Mulai session jika dibutuhkan untuk login
// session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Selamat Datang di Sistem Perpustakaan</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f1f1f1 url('baground library.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .container {
            background-color: rgba(255,255,255,0.9);
            max-width: 600px;
            margin: 80px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px #aaa;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        ul {
            list-style: none;
            padding-left: 0;
        }
        li {
            margin: 15px 0;
        }
        a {
            text-decoration: none;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            display: inline-block;
        }
        a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Selamat Datang di Sistem Perpustakaan</h1>
    <ul>
        <li><a href="login.php">Login</a></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="books.php">Daftar Buku</a></li>
        <li><a href="borrow.php">Peminjaman Buku</a></li>
        <li><a href="returns.php">Pengembalian Buku</a></li>
        <li><a href="loans.php">Data Peminjaman</a></li>
        <li><a href="fines.php">Denda</a></li>
    </ul>
</div>
</body>
</html>
